# C# Break out game tutorial in Visual Studio and Windows Form
In this tutorial we will make a simple break out game in windows form and visual studio. This game tutorial will be done step by step and I will show you how to make the game in two different ways. One way where we will put the picture boxes ourselves and the second way we will add the picture boxes to the windows form dynmically through the C# script. 

Video Tutorial - 

[![](http://img.youtube.com/vi/m18aCV-ox38/0.jpg)](http://www.youtube.com/watch?v=m18aCV-ox38 "MOO ICT make a break out game in windows form")

Written Tutorial - 
https://www.mooict.com/c-tutorial-create-a-breakout-game-in-visual-studio/
